public interface SlowTests{ /* category marker */
}