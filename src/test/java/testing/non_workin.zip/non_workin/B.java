package testing;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

@Category({SlowTest.class, FastTests.class})
public class B{
	@Test
	public void c(){
		
	}
}