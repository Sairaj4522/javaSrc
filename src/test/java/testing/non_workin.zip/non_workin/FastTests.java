public interface FastTests{ /* category marker */
}