package testing;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

@RunWith(Category.class)
@IncludeCategory(FastTests.class)
@ExcludeCategory(SlowTests.class)
@SuiteClasses({A.class, B.class})
// Note that Categories is a kind of Suite
public class FastTestSuite{
	
}