package testing;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

public class A{
	@Test
	public void a(){
		fail();
	}
	@Category(SlowTests.class)
	@Test
	public void b(){
	}
}