package testing;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

@RunWith(Category.class)
@IncludeCategory(SlowTests.class)
@ExcludeCategory(FastTests.class)
@SuiteClasses({A.class, B.class})
// Note that Categories is a kind of Suite
public class SlowTestSuite{
	// Will run A.b, but not A.a or B.c
}